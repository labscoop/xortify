var searchData=
[
  ['wgetserialisedxortifyexchange',['WGETSERIALISEDXortifyExchange',['../class_w_g_e_t_s_e_r_i_a_l_i_s_e_d_xortify_exchange.html',1,'']]],
  ['wgetxmlxortifyexchange',['WGETXMLXortifyExchange',['../class_w_g_e_t_x_m_l_xortify_exchange.html',1,'']]]
];
