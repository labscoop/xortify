var searchData=
[
  ['utf162utf8',['utf162utf8',['../class_services___j_s_o_n.html#a7167ad98617ca8b7887f0c7b4f514e0f',1,'Services_JSON']]],
  ['utf82utf16',['utf82utf16',['../class_services___j_s_o_n.html#aabc494819af90a318b2433bb74401eb8',1,'Services_JSON']]]
];
