var searchData=
[
  ['init',['init',['../class_providers.html#a332ffc04d7fe2bba92018db52ea3e4cc',1,'Providers']]],
  ['iserror',['isError',['../class_services___j_s_o_n.html#a2362480f2975e38784fd3f84042ddcb1',1,'Services_JSON']]]
];
