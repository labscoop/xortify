var searchData=
[
  ['xortify',['xortify',['../namespacexortify.html',1,'']]]
];
