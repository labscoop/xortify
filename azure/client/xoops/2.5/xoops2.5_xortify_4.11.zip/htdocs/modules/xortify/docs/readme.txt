Read Me First
=============

A bit about Xortify!

Xortify started out as a demo of the API X-JSON, X-CURL and X-SOAP for XOOPS 2 series and became a revolution in security 
for the XOOPS Platform. XOOPS comes with an application called Protector which prevents hacks and attacks to users of XOOPS 
and maintains a local ban list. This ban list is known as a bad IP that is an IP Addess which has attacked by trying to cause 
for example a DOS (Denial of Service/F5 Attack), injested unions and other forms of attack which protector by GIJOE from 
PEAK XOOPS - Support&Experiment in japan works on to prevent mal-users and would be hackers from exploiting the people that 
love xoops and other platforms.

Xortify is an application or process which first started as a practial application to cloud computing for the XOOPS Community 
which shares protectors bad IPs with a contingent of end users of the Xortify application and one you have signed up ensures 
that members share their bad ips in IPv4 or IPv6 for the host or proxy with each other so that we are protected from each 
others website forensically with protector. Here at http://xortify.chronolabs.coop (Mirrored on http://www.xortify.com our 
backup cloud) we host the current Bad IP List for the community so your website with the Xortify client running is pre-aware 
of a bad user and announces to them on all pages that they are banned unless the ban is cleared with one of our forms.

To be a contributor to the Xortify cloud you will need a username and password which you can sign up for in the software, 
you only need really one username and password per website or even per webmaster, it it really upto you. We also contribute 
to Stop Forum Spam as well as using Project Honeypot as a resource and are recieving their ban list as well. A ban is kept 
for 3 months then automatically removed from the system to ensure truency is in check we also only list a ban really only 
once not multiple times, sometimes a ban is listed twice when it is causing multiple intrusions on the network but this 
is a rarity.

Anyone can join Xortify and you don't need to use xortify's software to maintain, or put additional bans on the framework. 
If you happen to be a webmaster then you are welcome to view our API Documentation to see how we can intergrate with your 
environment. We offer wGET, CURL and SOAP api for you use. All you need is a username!!

CMS Supporting API Plugins or Modules

    XOOPS - http://bin.chronolabs.coop/xoops2.5_xortify_2.56.zip - 151Kb - Download Latest Version of Xortify for XOOPS 2.x
    XOOPS - http://bin.chronolabs.coop/xoops2.5_spiders_2.72.zip - 117Kb - Download Latest Version of Spiders for XOOPS 2.x

Songs Supporting API Plugins or Modules

    Xortify - http://bin.chronolabs.coop/xortify.mp3 - 4Mb - Download Binary Corpse Xortify Song
    
Contribute Plugins and Code Samples

Please keep adding to our archives here at chronolabs co-op if you have a file or link you would like to add to CMS 
Supporting API Plugins or Modules then contact us through the main contact for a quote or question form on 
http://www.chronolabs.coop.