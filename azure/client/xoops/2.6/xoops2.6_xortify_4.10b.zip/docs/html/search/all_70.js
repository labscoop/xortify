var searchData=
[
  ['protector',['protector',['../namespaceprotector.html',1,'']]],
  ['providers',['Providers',['../class_providers.html',1,'']]]
];
