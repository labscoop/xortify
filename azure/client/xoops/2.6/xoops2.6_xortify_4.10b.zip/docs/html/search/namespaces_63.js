var searchData=
[
  ['class',['class',['../namespaceclass.html',1,'']]]
];
