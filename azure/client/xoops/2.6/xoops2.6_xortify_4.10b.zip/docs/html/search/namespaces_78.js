var searchData=
[
  ['xortify',['Xortify',['../namespace_xortify.html',1,'Xortify'],['../namespacexortify.html',1,'xortify']]]
];
