var searchData=
[
  ['protector',['protector',['../namespaceprotector.html',1,'']]]
];
