var searchData=
[
  ['kernel',['kernel',['../namespacekernel.html',1,'']]]
];
