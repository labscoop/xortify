var searchData=
[
  ['init',['init',['../class_cache_apc.html#add47463221d657541f10f2ca5ec218d8',1,'CacheApc\init()'],['../class_cache_engine.html#add47463221d657541f10f2ca5ec218d8',1,'CacheEngine\init()'],['../class_cache_file.html#add47463221d657541f10f2ca5ec218d8',1,'CacheFile\init()'],['../class_cache_memcache.html#add47463221d657541f10f2ca5ec218d8',1,'CacheMemcache\init()'],['../class_cache_model.html#a5a352605cb6d44ea8c1b059e6413589c',1,'CacheModel\init()'],['../class_cache_xcache.html#a5a352605cb6d44ea8c1b059e6413589c',1,'CacheXcache\init()'],['../class_providers.html#afac76ed123e82d52003cb884b2e06e2e',1,'Providers\init()']]],
  ['iserror',['isError',['../class_services___j_s_o_n.html#a55ae0955466c3970507b122f3f5d1b38',1,'Services_JSON']]],
  ['isinitialized',['isInitialized',['../class_cache.html#a893f76ab9fd416c1558c366ff5936070',1,'Cache']]]
];
