var searchData=
[
  ['rest_5fcurl_2ephp',['rest_curl.php',['../rest__curl_8php.html',1,'']]],
  ['rest_5fcurlserialised_2ephp',['rest_curlserialised.php',['../rest__curlserialised_8php.html',1,'']]],
  ['rest_5fcurlxml_2ephp',['rest_curlxml.php',['../rest__curlxml_8php.html',1,'']]],
  ['rest_5fjson_2ephp',['rest_json.php',['../rest__json_8php.html',1,'']]],
  ['rest_5fwgetserialised_2ephp',['rest_wgetserialised.php',['../rest__wgetserialised_8php.html',1,'']]],
  ['rest_5fwgetxml_2ephp',['rest_wgetxml.php',['../rest__wgetxml_8php.html',1,'']]]
];
