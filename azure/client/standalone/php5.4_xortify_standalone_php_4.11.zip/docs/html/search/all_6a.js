var searchData=
[
  ['json_2ephp',['json.php',['../class_2json_8php.html',1,'']]],
  ['json_2ephp',['JSON.php',['../include_2json_8php.html',1,'']]],
  ['jsonxortifyexchange',['JSONXortifyExchange',['../class_j_s_o_n_xortify_exchange.html',1,'JSONXortifyExchange'],['../class_j_s_o_n_xortify_exchange.html#a5b94fbd0db11c88aaac5a4d6025957c5',1,'JSONXortifyExchange\JSONXortifyExchange()']]]
];
