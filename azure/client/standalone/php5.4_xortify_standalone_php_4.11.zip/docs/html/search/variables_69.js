var searchData=
[
  ['if',['if',['../rest__wgetxml_8php.html#adfcda37e07067335b32d169544e107e3',1,'if():&#160;rest_wgetxml.php'],['../soap_8php.html#a6146df301f89432497e6bfe9680af293',1,'if():&#160;soap.php'],['../wgetxml_8php.html#a121ad903444481b9834116cef5ea2f4d',1,'if():&#160;wgetxml.php'],['../index_8php.html#ae2ccdf355624402b65fc2226f2a661cd',1,'if():&#160;index.php']]]
];
