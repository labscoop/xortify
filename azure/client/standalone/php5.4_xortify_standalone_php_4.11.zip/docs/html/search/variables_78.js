var searchData=
[
  ['xoops_5fjson_5flib',['XOOPS_JSON_LIB',['../class_2json_8php.html#a42fbc26b113afc08a5757bacf456cd8a',1,'XOOPS_JSON_LIB():&#160;json.php'],['../rest__json_8php.html#a42fbc26b113afc08a5757bacf456cd8a',1,'XOOPS_JSON_LIB():&#160;rest_json.php']]],
  ['xoops_5fserial_5flib',['XOOPS_SERIAL_LIB',['../rest__wgetserialised_8php.html#a70ad743fdbf705daf2366b5cabf7a04d',1,'XOOPS_SERIAL_LIB():&#160;rest_wgetserialised.php'],['../wgetserialised_8php.html#a70ad743fdbf705daf2366b5cabf7a04d',1,'XOOPS_SERIAL_LIB():&#160;wgetserialised.php']]]
];
