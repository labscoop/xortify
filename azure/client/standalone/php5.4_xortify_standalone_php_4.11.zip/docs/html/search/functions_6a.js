var searchData=
[
  ['jsonxortifyexchange',['JSONXortifyExchange',['../class_j_s_o_n_xortify_exchange.html#a5b94fbd0db11c88aaac5a4d6025957c5',1,'JSONXortifyExchange']]]
];
