var searchData=
[
  ['utf162utf8',['utf162utf8',['../class_services___j_s_o_n.html#aa7b1b36cd3a4995bbb60f5def6a216e2',1,'Services_JSON']]],
  ['utf82utf16',['utf82utf16',['../class_services___j_s_o_n.html#af9687bbf6bcddc9c847d608f9a1fa4c0',1,'Services_JSON']]]
];
