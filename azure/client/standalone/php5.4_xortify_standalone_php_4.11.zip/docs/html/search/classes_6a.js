var searchData=
[
  ['jsonxortifyexchange',['JSONXortifyExchange',['../class_j_s_o_n_xortify_exchange.html',1,'']]]
];
