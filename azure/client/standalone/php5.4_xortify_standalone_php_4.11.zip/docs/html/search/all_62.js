var searchData=
[
  ['banned_2ephp',['banned.php',['../banned_8php.html',1,'']]]
];
